Phillip Bruce
Kalyan Bhetwal
Paul Vanderveen

# PA 1

## Overview

For PA 1, we wrote 5 algorithms in serialized form as a base for later parallelization attempts. We also created a build system and test suite that we should be able to use and/or build on in future projects. Below is a description of each algorithm and how it functions.

### Pi: Leibniz's Series



### Pi: Monte Carlo

The Monte Carlo algorithm calculates pi by imagining a circle inside a square, where the diameter of the circle is the same as the side length of the square. N random points are randomly chosen within the square and checked if they land within the circle as well. Then, the ratio of points inside the circle to total points tested (N) is multiplied by 4. The result should be a close estimate of the value of pi, with the number being more accurate with a higher N.

### Matrix-Vector Multiply



### Matrix-Matrix Multiply



### Fibonacci Numbers