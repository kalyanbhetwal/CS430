#include "monte-carlo.h"
int main(int argc, char *argv[]) {
    printf("%f\n", monteCarlo(99999999));
}